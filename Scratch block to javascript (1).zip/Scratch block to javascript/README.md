# Scratch2js
Essentially [Scratch2js](https://github.com/epicdude2121/Scratch-block-to-javascript)
# How to install:
1. Clone/Download this repository
2. Go to chrome://extenions
3. Enable Developer Mode
4. Click Load unpacked extension
5. Select the downloaded/cloned folder